package com.cg.registration.stepdefinition;

import org.junit.After;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.registration.pagebeans.RegistrationPageBean;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RegistrationStepDefinition {

private WebDriver driver;

	private RegistrationPageBean pageBean;

	@Before

	public void setUpStepEnv() {

		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");

		driver=new ChromeDriver();
	}


	@Given("^User is accessing Conference Registration Page on Borwser$")

	public void user_is_accessing_Conference_Registration_Page_on_Borwser() throws Throwable {

		driver.get("D:\\Set B\\ConferenceRegistartion.html");

		pageBean = PageFactory.initElements(driver, RegistrationPageBean.class);
	}

	@When("^user is trying submit data without entring 'First Name'$")

	public void user_is_trying_submit_data_without_entring_First_Name() throws Throwable {

		pageBean.clickNext();

	}

	@Then("^'Please fill the First Name' alert message should display$")

	public void please_fill_the_First_Name_alert_message_should_display() throws Throwable {

		String expectedAlertMessage ="Please fill the First Name";

		String actualAlertMessage=driver.switchTo().alert().getText();

		Assert.assertEquals(expectedAlertMessage, actualAlertMessage);

	}

	@When("^user is trying submit data without entring 'Last Name'$")

	public void user_is_trying_submit_data_without_entring_Last_Name() throws Throwable {

		driver.switchTo().alert().dismiss();

		pageBean.setTxtFN("gunjan");

		pageBean.clickNext();

	}



	@Then("^'Please fill the Last Name' alert message should display$")

	public void please_fill_the_Last_Name_alert_message_should_display() throws Throwable {

		String expectedAlertMessage ="Please fill the Last Name";

		String actualAlertMessage=driver.switchTo().alert().getText();

		Assert.assertEquals(expectedAlertMessage, actualAlertMessage);

	}



	@When("^User is trying to submit request without entering valid 'email'$")

	public void user_is_trying_to_submit_request_without_entering_valid_email() throws Throwable {

		driver.switchTo().alert().dismiss();

		pageBean.setTxtLN("Vohra");

		pageBean.clickNext();

	}



	@Then("^'Please fill the Email' alert message should display$")

	public void please_fill_the_Email_alert_message_should_display() throws Throwable {

		String expectedAlertMessage="Please fill the Email";

		String actualAlertMessage=driver.switchTo().alert().getText();

		Assert.assertEquals(expectedAlertMessage, actualAlertMessage);



	}



	@When("^user is trying submit data without entering 'Contact No\\.'$")

	public void user_is_trying_submit_data_without_entering_Contact_No() throws Throwable {

		driver.switchTo().alert().dismiss();

		pageBean.setEmail("gunjanv1145@gmail.com");

		pageBean.clickNext();

	}



	@Then("^'Please fill the Contact No\\.' alert message should display$")

	public void please_fill_the_Contact_No_alert_message_should_display() throws Throwable {

		String expectedAlertMessage="Please fill the Contact No.";

		String actualAlertMessage=driver.switchTo().alert().getText();

		Assert.assertEquals(expectedAlertMessage, actualAlertMessage);

	}



	@When("^user is trying submit data without entering valid 'Contact No\\.'$")

	public void user_is_trying_submit_data_without_entering_valid_Contact_No() throws Throwable {

		driver.switchTo().alert().dismiss();

		pageBean.setEmail("gunjanv1145@gmail.com");

		pageBean.setPhone("gunjsanm");

		pageBean.clickNext();

	}



	@Then("^'Please enter valid Contact No\\.' alert message should display$")

	public void please_enter_valid_Contact_No_alert_message_should_display() throws Throwable {

		String expectedAlertMessage="Please enter valid Contact no.";

		String actualAlertMessage=driver.switchTo().alert().getText();

		Assert.assertEquals(expectedAlertMessage, actualAlertMessage);

	}



	@When("^User is trying to submit request without selecting 'Number of people attending'$")

	public void user_is_trying_to_submit_request_without_selecting_Number_of_people_attending() throws Throwable {

		driver.switchTo().alert().dismiss();

		pageBean.setPhone("7087867982");

		pageBean.clickNext();

	}



	@Then("^'Number of people attending' alert message should display$")

	public void number_of_people_attending_alert_message_should_display() throws Throwable {

		String expectedAlertMessage="Please fill the Number of people attending";

		String actualAlertMessage=driver.switchTo().alert().getText();

		Assert.assertEquals(expectedAlertMessage, actualAlertMessage);

	}



	@When("^user is trying submit data without entering 'Building Name & Room No\\.'$")

	public void user_is_trying_submit_data_without_entering_Building_Name_Room_No() throws Throwable {

		driver.switchTo().alert().dismiss();

		pageBean.setSize("4");

		pageBean.clickNext();

	}



	@Then("^'Please fill the Building & Room No\\.' alert message should display$")

	public void please_fill_the_Building_Room_No_alert_message_should_display() throws Throwable {

		String expectedAlertMessage="Please fill the Building & Room No";

		String actualAlertMessage=driver.switchTo().alert().getText();

		Assert.assertEquals(expectedAlertMessage, actualAlertMessage);

	}



	@When("^User is trying to submit request without entering 'Area name'$")

	public void user_is_trying_to_submit_request_without_entering_Area_name() throws Throwable {

		driver.switchTo().alert().dismiss();

		pageBean.setAddress("thomson 1d");

		pageBean.clickNext();

	}



	@Then("^'Please fill the Area name' alert message should display$")

	public void please_fill_the_Area_name_alert_message_should_display() throws Throwable {

		String expectedAlertMessage="Please fill the Area name";

		String actualAlertMessage=driver.switchTo().alert().getText();

		Assert.assertEquals(expectedAlertMessage, actualAlertMessage);

	}



	@When("^User is trying to submit request without selecting 'City'$")

	public void user_is_trying_to_submit_request_without_selecting_City() throws Throwable {

		driver.switchTo().alert().dismiss();

		pageBean.setAddress2("panchkula");

		pageBean.clickNext();



	}



	@Then("^'Please select city' alert message should display$")

	public void please_select_city_alert_message_should_display() throws Throwable {

		String expectedAlertMessage="Please select city";

		String actualAlertMessage=driver.switchTo().alert().getText();

		Assert.assertEquals(expectedAlertMessage, actualAlertMessage);

	}



	@When("^User is trying to submit request without selecting 'State'$")

	public void user_is_trying_to_submit_request_without_selecting_State() throws Throwable {

		driver.switchTo().alert().dismiss();

		pageBean.setCity("Bangalore");

		pageBean.clickNext();

	}



	@Then("^'Please select state' alert message should display$")

	public void please_select_state_alert_message_should_display() throws Throwable {

		String expectedAlertMessage="Please select state";

		String actualAlertMessage=driver.switchTo().alert().getText();

		Assert.assertEquals(expectedAlertMessage, actualAlertMessage);

	}



	@When("^User is trying to submit request without entring valid 'MemberShip status'$")

	public void user_is_trying_to_submit_request_without_entring_valid_MemberShip_status() throws Throwable {

		driver.switchTo().alert().dismiss();

		pageBean.setState("Karnataka");

		pageBean.clickNext();

	}



	@Then("^'Please Select MemberShip status' alert message should display$")

	public void please_Select_MemberShip_status_alert_message_should_display() throws Throwable {

		String expectedAlertMessage="Please Select MemeberShip status";

		String actualAlertMessage=driver.switchTo().alert().getText();

		Assert.assertEquals(expectedAlertMessage, actualAlertMessage);

	}
	
	@After

	public void tearDownStepEnv() {

		driver.close();

	}

}