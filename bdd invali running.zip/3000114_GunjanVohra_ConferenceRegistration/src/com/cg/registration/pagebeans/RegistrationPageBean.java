package com.cg.registration.pagebeans;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.Select;

public class RegistrationPageBean {

	@FindBy(how=How.NAME,name="txtFN")

	private WebElement txtFN ;



	@FindBy(how=How.NAME,name="txtLN")

	private WebElement txtLN;



	@FindBy(how=How.NAME,name="Email")

	private WebElement Email;



	@FindBy(how=How.NAME,name="Phone")

	private WebElement Phone;



	@FindBy(how=How.NAME,name="size")

	private WebElement size;



	@FindBy(how=How.NAME,name="Address")

	private WebElement Address;



	@FindBy(how=How.NAME,name="Address2")

	private WebElement Address2;



	@FindBy(how=How.NAME,name="city")

	private WebElement city;



	@FindBy(how=How.NAME,name="state")

	private WebElement state;



	@FindBy(how=How.NAME,name="memberStatus")

	private List<WebElement> memberStatus;



	@FindBy(how=How.LINK_TEXT,linkText="Next")

	private WebElement next;



	public String getTxtFN() {

		return txtFN.getAttribute("value");

	}



	public void setTxtFN(String txtFN) {

		this.txtFN.clear();

		this.txtFN.sendKeys(txtFN);

	}



	public String getTxtLN() {

		return txtLN.getAttribute("value");

	}



	public void setTxtLN(String txtLN) {

		this.txtLN.sendKeys(txtLN);

	}



	public String getEmail() {

		return Email.getAttribute("value");

	}



	public void setEmail(String Email) {

		this.Email.clear();

		this.Email.sendKeys(Email);

	}



	public String getPhone() {

		return Phone.getAttribute("value");

	}



	public void setPhone(String Phone) {

		this.Phone.clear();

		this.Phone.sendKeys(Phone);

	}



	public String getCity() {

		return new Select(this.city).getFirstSelectedOption().getText();

	}



	public void setCity(String city) {

		Select select=new Select(this.city);

		select.selectByVisibleText(city);

	}



	public String getState() {

		return new Select(this.state).getFirstSelectedOption().getText();

	}



	public void setState(String state) {

		Select select=new Select(this.state);

		select.selectByVisibleText(state);

	}



	public String getSize() {

		return size.getAttribute("value");

	}



	public void setSize(String size) {

		this.size.sendKeys(size);

	}



	public String getAddress() {

		return Address.getAttribute("value");

	}



	public void setAddress(String Address) {

		this.Address.sendKeys(Address);

	}



	public String getAddress2() {

		return Address2.getAttribute("value");

	}



	public void setAddress2(String Address2) {

		this.Address2.sendKeys(Address2);

	}



	public String getMemberStatus() {

		for (WebElement webElement : memberStatus)

			if(webElement.isSelected())

				return webElement.getAttribute("value");

		return null;

	}



	public void setMemberStatus(String memberStatus) {

		if(memberStatus.equalsIgnoreCase("member"))

			this.memberStatus.get(0).click();

		else

			this.memberStatus.get(1).click();

	}

	public void clickNext() {

		next.click();

	}

}